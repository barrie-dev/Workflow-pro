# WorkFlow Pro Fullstack

Deze map is de productiegerichte ontwikkellijn. De bestaande flat app blijft de visual/prototype-zone.

## Start

```powershell
cd "C:\Users\ABMS Consultancy\Documents\New project\WorkFlowPro-fullstack"
npm start
```

Open:

```text
http://localhost:4280
```

## Focus

- Auth en sessies
- Server-side tenant isolation
- Server-side rechten
- Auditlog
- Encrypted credentials
- Golden path API
- Stripe/Peppol-ready billing service
- Mobile-first today API

Deze versie gebruikt voorlopig JSON-opslag met repository boundaries. De database target staat in `db/schema.sql` voor PostgreSQL/Supabase.
