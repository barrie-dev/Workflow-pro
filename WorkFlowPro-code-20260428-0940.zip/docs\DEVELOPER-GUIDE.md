# WorkFlow Pro Developer Guide

Versie: 0.1 local SaaS prototype  
Datum: 2026-04-27

## Doel

WorkFlow Pro is een B2B SaaS-app voor Belgische KMO's met veldpersoneel. De huidige codebase is een werkende lokale SaaS-demo met React in de browser, een kleine Node HTTP-server, server-side JSON-opslag en fallback naar browseropslag.

Deze guide beschrijft hoe je lokaal ontwikkelt, hoe de bestanden zijn opgebouwd, waar state zit en welke onderdelen productie-klaar gemaakt moeten worden.

## Projectstructuur

```text
New project/
  app.js                         Frontend applicatie
  index.html                     App shell en scriptloader
  react-all.js                   Gebundelde React + ReactDOM runtime
  server.js                      Lokale HTTP-server en API endpoints
  package.json                   Scripts en projectmetadata
  .env.example                   Voorbeeldconfiguratie
  data/
    .gitkeep                     Houdt de datafolder in versiebeheer
    workflow-pro-db.json         Lokale server-state, ontstaat bij opslaan
  docs/
    DEVELOPER-GUIDE.md
    TECHNICAL-ARCHITECTURE.md
    APP-FEATURE-INVENTORY.md
    SECURITY-IMPLEMENTATION.md
```

## Starten

Aanbevolen voor SaaS-modus:

```powershell
.\Start WorkFlow Pro.bat
```

Open:

```text
http://localhost:4173
```

Health check:

```text
http://localhost:4173/api/health
```

Direct openen zonder server kan via `Open WorkFlow Pro.bat`, maar dan werkt alleen browseropslag en niet de API-laag.

## Beschikbare scripts

```powershell
npm start
npm run check
```

Let op: op deze machine staat `npm` mogelijk niet in PATH. De `.bat` gebruikt daarom de meegeleverde Node-runtime direct.

## Frontend overzicht

Alles zit momenteel in `app.js`. Het bestand bevat:

- Design tokens en gedeelde UI-atoms
- Seed data
- Permission helpers
- Scope helpers voor tenant/venue filtering
- Pagina-componenten
- Main `App()` component met navigatie, state en routing

Belangrijke frontend secties:

```text
Permissions        ALL_PERMS, ROLE_DEFAULTS, PLAN_LIMITS, hasPerm()
Seed data          USERS, TENANTS, VENUES, SHIFTS, CLOCKS, etc.
UI atoms           Av, Chip, RoleBadge, Btn, Modal, Inp, Sel, Card, KPI
Pages              Dashboard, GoldenPath, Readiness, Lifecycle, Security, Onboarding, Alerts, Datahub, Planning, Expenses, Workorders, etc.
Governance         EmployeesPage, AuditPage, SettingsPage
Platform owner     PlatformOwnerPage, platformConfig
Billing            BillingOpsPage voor super admin, BillingPage voor klantabonnementen, PLANS, ADD_MODS
Integrations       IntegrationsPage, SECRETARIATEN
App shell          App(), NAV arrays, renderPage()
```

Nieuwe go-to-market hardening:

- `OnboardingPage`: tenant go-live checklist en snelle medewerkersimport
- `GoldenPathPage`: centrale klantactivatie-flow van KBO tot eerste factuur, met demo-aanmaak voor medewerkers, planning, werkbon, tijdregistratie en factuur
- `AlertsPage`: actiecentrum met operationele signalen
- `DataHubPage`: CSV exports voor medewerkers, venues, onkosten, werkbonnen en stock
- `ReadinessPage`: super-admin product owner cockpit voor go-live maturiteit
- `LifecyclePage`: super-admin customer-success cockpit voor trial, health, billing en renewal
- `SecurityPage`: super-admin cockpit voor MFA, tenant isolation, credentials, GDPR/DPA en security events
- `BillingOpsPage`: super-admin facturatieconsole voor klantcontacten, maatwerkprijzen, kortingen, jaarlijkse auto-renew, tokenized betaalmethode, factuuraanmaak en Peppol-status

Security productieplan:

- `docs/SECURITY-IMPLEMENTATION.md`

## State model

De applicatie start met `INIT`. Die bestaat uit:

- `users`
- `tenants`
- `venues`
- `shifts`
- `clocks`
- `expenses`
- `workorders`
- `leaves`
- `messages`
- `vehicles`
- `stock`
- `customTypes`
- `expLimits`
- `customRoles`
- `auditLogs`
- `platformConfig`
- `securityPolicy`
- `securityEvents`

State wordt bijgewerkt via `upd(key, value)`. Deze helper:

- ondersteunt directe waarden en functionele updates
- normaliseert data via `normalizeData()`
- schrijft kritieke wijzigingen automatisch naar `auditLogs`

`platformConfig` bevat beheerbare SaaS-owner instellingen:

- plannen, prijzen en trialdagen
- add-on modules en moduleprijzen
- BTW, jaarkorting, factuurprefix en dunningbeleid
- Stripe mode en configuratiestatus
- feature flags
- supportbeleid

Let op: in de lokale demo is dit gewone JSON-state. Productie moet Stripe secrets en gevoelige provider credentials server-side versleuteld opslaan.

## Opslag

Servermodus:

```text
GET  /api/state
PUT  /api/state
POST /api/bootstrap
```

De server schrijft naar:

```text
data/workflow-pro-db.json
```

Browser fallback:

```text
localStorage key: workflow-pro-saas-state-v1
```

## API endpoints

```text
GET  /api/health
GET  /api/state
PUT  /api/state
POST /api/bootstrap
POST /api/integrations/robaws/test
POST /api/integrations/robaws/sync
```

De Robaws endpoints zijn lokale simulaties. Ze valideren input en tonen hoe de productie-integratie later moet worden aangesloten.

## Rechten en rollen

Basisrollen:

- `super_admin`
- `tenant_admin`
- `venue_manager`
- `employee`

Vrije rollen:

- worden opgeslagen in `customRoles`
- hebben `id`, `tenantId`, `name`, `desc`, `permissions`
- kunnen worden aangemaakt in `EmployeesPage`

Module-permissies:

```text
planning
clockings
expenses
workorders
stock
vehicles
leaves
messages
reports
integrations
billing
employees
venues
audit
```

Belangrijk: in deze demo worden rechten vooral frontend-side toegepast. Voor productie moeten dezelfde checks server-side via JWT en database policies worden afgedwongen.

## Testen

Minimale checks na wijzigingen:

```powershell
node --check app.js
node --check server.js
```

Handmatige smoke test:

1. Start server.
2. Open `/api/health`.
3. Open app.
4. Login als admin.
5. Maak een vrije rol.
6. Nodig medewerker uit met die rol.
7. Controleer `Auditlog`.
8. Bewerk tenant plan/status.
9. Herlaad met `Ctrl + F5`.

## Productie-taken

Voor echte marktgang moeten deze onderdelen uit de demo gehaald of vervangen worden:

- JSON-file opslag vervangen door PostgreSQL/Supabase.
- Auth vervangen door echte login/JWT.
- Rechten server-side afdwingen.
- Stripe Checkout/Customer Portal/Webhooks aansluiten.
- Robaws en sociale secretariaten via echte API credentials koppelen.
- Auditlog append-only maken.
- File uploads naar object storage brengen.
- Error monitoring en logging toevoegen.
- E2E tests toevoegen.
