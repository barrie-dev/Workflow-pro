# WorkFlow Pro App Feature Inventory

Versie: 0.1 local SaaS prototype  
Datum: 2026-04-27

## Productpositionering

WorkFlow Pro is een SaaS-platform voor Belgische KMO's met veldpersoneel. De app combineert personeelsplanning, tijdregistratie, werkbonnen, onkosten, stock, wagenpark, rollen/rechten, rapportage, billing en integraties.

Primaire doelgroep:

- Bouwbedrijven
- Technische diensten
- Logistieke KMO's
- Schoonmaakbedrijven
- Bedrijven met medewerkers op locatie of onderweg

## Rollen

### Super Admin

Platformbeheerder. Ziet alle tenants, MRR, ARR, abonnementen en platformrapportages.

GDPR-principe: Super Admin beheert het platform, maar krijgt niet standaard toegang tot persoonsgegevens van medewerkers binnen klanttenants. Klantdata is alleen toegankelijk via tenantcontext, actieve supporttoestemming en auditspoor.

Beschikbare onderdelen:

- Platform dashboard
- Golden path cockpit
- SaaS klantenfiches / tenantbeheer
- Platform beheer
- Go-live readiness
- SaaS lifecycle
- Security Center
- Rapportages
- Billing

Extra platformbeheer:

- Prijzen per plan aanpassen
- Abonnementsbundels configureren: per plan bepalen welke onderdelen inbegrepen zijn
- Trialdagen, BTW, jaarkorting, factuurprefix en dunningbeleid beheren
- Extra modules activeren/deactiveren en prijzen wijzigen
- Stripe test/live mode en configuratiestatus beheren
- Admin-rechten centraal beheren voor alle tenants
- Feature flags beheren
- Supporttoegang per tenant controleren
- Inloggen als klantadmin voor support, alleen bij actieve klanttoestemming
- Billing operations voor enterprise en maatwerkklanten:
- facturatiecontact per klant beheren
- klantafhankelijke jaarprijzen en kortingen vastleggen
- enterprise contracten tonen als "op maat" in plaats van publieke prijs
- jaarlijkse auto-renew contracten beheren
- tokenized kaartbetaalmethode registreren voor automatische afhaling
- facturen aanmaken vanuit super admin
- Peppol ID, Peppol readiness en Peppol-verzendstatus opvolgen

SaaS klantenfiche:

- tenantnaam, plan, status en billing e-mail
- MRR, lifecycle, churn risk en renewal datum
- account owner
- support tickets
- customer success notitie
- facturatiecontact en betaalmethode-status
- contractprijs, korting, renewal en factuurhistoriek
- aparte tabs voor overzicht & facturatie, contactpersoon, account manager en customer success
- facturatietab met juridische naam uit hoofdbenaming, BTW/ondernemingsnummer, facturatieadres, facturatie e-mail, Peppol ID, betaaltermijn, factuurtaal, PO-verplichting en facturatienotities
- KBO-ophaalactie op basis van Belgisch BTW-nummer om bedrijfsnaam, ondernemingsnummer en adres automatisch te vullen
- account manager-tab met sales responsible, account manager, customer success manager, lead/source, commerciele fase, laatste contact, volgende review en accountnotities

### Go-live readiness

Product owner cockpit voor de SaaS-eigenaar:

- 12 maturiteitsdomeinen: onboarding, rollen/rechten, super admin, billing, integraties, data import/export, rapportage, mobiel, notificaties, security/compliance, UX en positionering
- score per domein
- prioriteit P0/P1/P2
- owner
- wat al aanwezig is
- wat nog nodig is voor marktgang
- aangescherpte productpositionering en kernpijlers

### Golden path

Centrale productflow voor verkoopbare SaaS-activatie:

- nieuwe klant selecteren of openen
- KBO/facturatiegegevens controleren
- onboarding checklist opvolgen
- demo-medewerkers aanmaken wanneer import nog leeg is
- eerste planning aanmaken
- eerste werkbon aanmaken
- tijdregistratie toevoegen
- eerste factuur aanmaken
- werksporen tonen voor backend foundation, productie-billing, mobiele veldflow en UX-sanering

### SaaS lifecycle

Dagelijkse customer-success cockpit voor de SaaS-eigenaar:

- tenant health score
- churn risk
- trial einde
- payment failed
- billing status
- account owner
- renewal datum
- laatste activiteit
- open support tickets
- customer success playbooks
- sales/demo mode checklist

### Security Center

Super-admin cockpit voor B2B security readiness:

- MFA/auth beleid
- sessieduur en idle timeout
- IP/device logging
- tenant isolation status
- DPA verplichting
- GDPR export/delete status
- credential vault status
- Stripe en integratie secret handling
- support access governance
- security events met tenant, actor, IP en device
- go-live security gates met score

### Tenant Admin

Bedrijfsbeheerder binnen één tenant.

De standaard Admin-rol wordt centraal beheerd door de Super Admin via Platform beheer. Klanten kunnen wel vrije rollen aanmaken, maar niet zelf de basisrechten van de Admin-rol wijzigen.

Beschikbare onderdelen:

- Dashboard
- Actiecentrum
- Venues
- Klanten
- Medewerkers
- Planning & taken
- Tijdregistraties
- Onkosten
- Werkbonnen
- Verlof
- Berichten
- Wagenpark
- Stock
- Rapportages
- Datahub
- Integraties
- Abonnementen
- Instellingen
- Auditlog

Tenant-instellingen:

- Onkostenlimieten
- Kilometervergoeding
- Supporttoegang tijdelijk inschakelen of intrekken
- Go-live checklist

### Onboarding

Super Admin go-live module voor nieuwe klanten:

- voortgangsbalk per tenant
- checklist voor bedrijf, venues, medewerkers, rollen, billing en integraties
- stappen per tenant afvinken vanuit platformniveau
- wizard voor bedrijfsgegevens, facturatie e-mail, BTW en sector
- Excel/CSV preview voor medewerkersimport
- snelle medewerkersimport via geplakte CSV-regels
- eerste planning aanmaken vanuit onboarding
- integratiekoppeling markeren na test/sandbox controle
- go-live gates voor mobiel gebruik, billing, supportbeleid en export

### Actiecentrum

Operationele signalen die opvolging vragen:

- onkosten in goedkeuring
- verlofaanvragen
- stock onder minimum
- voertuigen met service binnen 14 dagen
- werkbonnen met bijlagen te reviewen
- doorlopende supporttoegang

### Datahub

Basis exportlaag voor onboarding en finance:

- medewerkers CSV
- venues CSV
- klanten CSV
- onkosten CSV
- werkbonnen CSV
- stock CSV

Importcentrum:

- CSV plakken met headerregel
- importtype kiezen
- voorbeelddata laden
- preview van de eerste rijen controleren
- importeren naar medewerkers, klanten, venues, stock of voertuigen
- import is geblokkeerd op Super Admin platformniveau voor klant-persoonsdata

GDPR guardrail:

- Super Admin ziet in Datahub alleen platformmetadata zoals tenantstatus, plan, MRR en supporttoegang.
- Persoonsgebonden klantdata zoals medewerkers, onkosten, werkbonnen en klantcontacten is geblokkeerd op platformniveau.
- Export van klant-persoonsdata gebeurt alleen vanuit tenantcontext of supportsessie met actieve klanttoestemming.
- Supporttoegang moet door de klant worden ingeschakeld en hoort in productie altijd gelogd te worden met reden, actor, tijdstip en scope.

### Venue Manager / Werfleider

Beheerder van één of meerdere locaties/werven.

Beschikbare onderdelen:

- Dashboard
- Planning & taken
- Tijdregistraties
- Onkosten
- Werkbonnen
- Verlof
- Berichten
- Stock

### Medewerker

Veldmedewerker met beperkte modules.

Beschikbare onderdelen afhankelijk van permissies:

- Dashboard
- Prikklok
- Mijn taken
- Onkosten
- Werkbonnen
- Verlof
- Berichten
- Wagenpark

### Vrije rollen

Tenant admins kunnen eigen rollen aanmaken, bijvoorbeeld:

- Planner
- Finance
- Field Lead
- Externe accountant
- Office manager

Per rol kan men kiezen welke modules zichtbaar zijn.

Uitgebreide rechtenmatrix:

- rechten per actie: bekijken, aanmaken, wijzigen, verwijderen, goedkeuren en exporteren
- venue scope: alleen eigen data, teamdata, specifieke venue, hele tenant of alle tenants
- datagevoeligheid: publiek, intern, vertrouwelijk, loon/HR of financieel gevoelig
- rol-preview tijdens het aanmaken van een vrije rol
- auditlog voor rechtenwijzigingen met oude en nieuwe waarde

### Klanten

Tenant CRM-module voor de klanten van de klant:

- klantenfiche met bedrijfsnaam, contactpersoon, e-mail, telefoon en adres
- BTW-nummer, sector en betalingstermijn
- status: actief, prospect of on hold
- account owner binnen de tenant
- tags en interne notities
- export via Datahub

## Module-overzicht

## Login

Demo-login met rolkeuze:

- Super Admin
- Admin Claes
- Werfleider Kim
- Lena De Smet
- Jarne Claes

Doel: snel verschillende rolperspectieven testen.

## Dashboard

### Platform dashboard

Voor super admin:

- Actieve klanten
- MRR
- ARR
- Geschorste klanten
- Trials
- Totaal gebruikers
- Overzicht van tenants

### Admin dashboard

Voor tenant admin en werfleider:

- Venues
- Medewerkers
- Planning vandaag
- Open onkosten
- Werkbonnen
- Open verlofaanvragen
- Berichten

### Medewerker dashboard

Voor medewerkers:

- Komende taken
- Open werkbonnen
- Ingediende onkosten
- Verlofstatus
- Prikklokstatus

## Venues

Locatiebeheer per tenant.

Functionaliteit:

- Venue aanmaken
- Venue bewerken
- Code instellen
- Kleur instellen
- Adres instellen
- Actieve gebruikers per venue zien

Voorbeelden:

- Hoofdkantoor Gent
- Magazijn Noord
- Werf Brussel

## Medewerkers

Medewerkersbeheer.

Functionaliteit:

- Medewerkers bekijken
- Medewerker uitnodigen
- Medewerkersfiche bewerken: naam, e-mail, telefoon, afdeling, rol en primaire venue
- Rol kiezen
- Vrije rol toekennen
- Primaire venue instellen
- Venue-toegang beheren
- Module-permissies beheren
- Medewerker activeren/deactiveren

Nieuwe governance-features:

- Vrije rol aanmaken
- Vrije rol bewerken en verwijderen
- Omschrijving per rol
- Module-rechten per rol
- Rolkaarten met aantal rechten
- Klantadmin kan alle medewerkers binnen de tenant beheren
- Custom rollen kunnen medewerkers beheren wanneer de rol medewerkers + wijzigrechten heeft
- Wijzigingen aan rol, venue-scope, gevoeligheid en rechten worden gelogd met oude en nieuwe waarde

## Planning & Taken

Weekplanning voor medewerkers en locaties.

Functionaliteit:

- Weeknavigatie
- Taken per dag en medewerker
- Nieuwe shift/taak toevoegen
- Shift/taak bewerken
- Shift/taak verwijderen
- Type taak kiezen
- Project en klant vastleggen
- Factureerbaar markeren
- Notitie toevoegen

Vrije taakvelden:

- Leidingwerk
- Elektriciteit
- Ruwbouw
- Vergadering
- Opleiding

Admins kunnen extra taaktypes aanmaken.

## Prikklok

Medewerker-prikklok.

Functionaliteit:

- Live klok
- Inklokken
- Uitklokken
- Vandaagstatus
- Historiek tonen

## Tijdregistraties

Admin/manager overzicht.

Functionaliteit:

- Uren per medewerker
- Totaal gepresteerde uren
- Clock-in/clock-out overzicht
- Datumweergave

## Onkosten

Onkostenbeheer voor medewerkers en admins.

Functionaliteit:

- Onkosten indienen
- Categorie kiezen
- Bedrag invullen
- Datum invullen
- Omschrijving
- Bon upload simulatie
- Kilometeronkosten
- Voertuig koppelen
- Factureerbaar aan klant markeren
- Goedkeuren
- Afwijzen
- Uitbetalen
- Review-notitie

Categorieen:

- Brandstof
- Parking
- Tolkosten
- Maaltijden
- Hotel
- Kantoormateriaal
- Gereedschap
- Verzending
- Software
- Training
- Representatie
- Kilometers
- Overig

## Werkbonnen

Digitale werkbonnen voor veldwerk.

Functionaliteit:

- Werkbon aanmaken
- Klant en locatie invullen
- Omschrijving
- Datum
- Status
- Factureerbare uren
- Checklist beheren
- Materialen toevoegen vanuit stock
- Stock automatisch verminderen
- Bijlagen upload simulatie
- Werkbon ondertekenen
- Admin-review
- Werkbon verwijderen

Statussen:

- Bezig
- In behandeling
- Voltooid

## Verlof

Verlofbeheer.

Functionaliteit:

- Verlof aanvragen
- Type kiezen
- Datum van/tot
- Notitie toevoegen
- Admin goedkeuren
- Admin weigeren
- Statusoverzicht

Types:

- Verlof
- Ziekte

## Berichten

Interne communicatie.

Functionaliteit:

- Berichten sturen
- Berichten ontvangen
- Admin/manager kan medewerkers kiezen
- Medewerker kan admin/manager contacteren
- Ongelezen badges in navigatie

## Stockbeheer

Voorraadbeheer per venue.

Functionaliteit:

- Artikelen bekijken
- Artikel toevoegen
- Artikel bewerken
- Artikel verwijderen
- Minimumvoorraad instellen
- Lage stock waarschuwing
- Locatie en categorie
- Stockgebruik via werkbonnen

Voorbeeldartikelen:

- Oliefilter
- Remblokken
- Wisserbladen
- Motorolie
- Koelvloeistof

## Wagenpark

Voertuigbeheer.

Functionaliteit:

- Voertuigen bekijken
- Voertuig toevoegen
- Voertuig bewerken
- Voertuig verwijderen
- Nummerplaat
- Merk/model
- Kilometerstand
- Brandstof
- Status
- Bestuurder toewijzen
- Volgende service
- Service-alert

Statussen:

- Beschikbaar
- In gebruik
- Onderhoud
- Defect

## Rapportages

Analyse en rapportage.

Functionaliteit:

- Datumfilter
- Venuefilter
- Urenoverzicht
- Onkostenoverzicht
- Kilometeroverzicht
- Werkbonnen
- Factureerbare uren
- Categorieverdeling onkosten
- Taakvelden in periode
- Medewerkerdetail

## Integraties

Integratiebeheer met DPA-flow.

Beschikbare integraties:

- Acerta
- Liantis
- SD Worx
- Securex
- Partena Professional
- Robaws

Flow:

1. DPA bevestigen
2. Datavelden selecteren
3. API configureren
4. Verbinding testen
5. Activatie
6. Sync uitvoeren

Robaws velden:

- Klanten
- Projecten
- Werkbonnen
- Materialen
- Uren
- Facturatie

Lokale API-simulaties:

- Robaws test
- Robaws sync

## Billing / Abonnementen

SaaS billing simulatie.

Plans:

- Starter
- Business
- Enterprise

Extra modules:

- Werkbonnen Pro
- Wagenpark
- Stockbeheer
- Integraties

Functionaliteit:

- Plan kiezen
- Inbegrepen onderdelen worden uit Platform beheer gelezen
- Aantal gebruikers instellen
- Maandelijks/jaarlijks kiezen
- Jaarkorting
- BTW-berekening
- Checkout wizard
- Stripe simulatie
- Betalingssucces flow

## Tenantbeheer

Super admin module.

Functionaliteit:

- Nieuwe tenant aanmaken
- Tenant bewerken
- Plan kiezen
- Status beheren
- Billing e-mail
- MRR tonen
- Planlimieten tonen

Planlimieten:

- users
- venues
- vrije rollen
- integraties
- auditretentie

## Instellingen

Tenantinstellingen.

Functionaliteit:

- Onkostlimieten per categorie
- Kilometervergoeding tonen
- Go-live checklist

Go-live checklist:

- Rollen & rechten
- Billing
- Data import
- Integraties
- Audit & compliance

## Auditlog

Compliance en governance pagina.

Functionaliteit:

- Auditregels bekijken
- Filteren per area
- Actor zien
- Datum/tijd zien
- Detail van wijziging

Areas:

- Rechten
- Tenant
- Abonnement
- Integraties
- Instellingen
- Operationele data

Automatisch gelogde wijzigingen:

- users
- tenants
- venues
- customRoles
- expLimits
- expenses
- workorders
- integrations

## Data en opslag

Servermodus:

- wijzigingen worden opgeslagen via `/api/state`
- data staat in `data/workflow-pro-db.json`

Directe HTML-modus:

- wijzigingen worden opgeslagen in browser `localStorage`

## Modulepreviews

Elke module heeft een eerste-bezoek preview overlay.

Functionaliteit:

- korte uitleg per module
- drie concrete stappen die aangeven wat de bedoeling is
- lokaal onthouden per rol en module
- knop om alle previews uit te zetten
- bedoeld om onboarding en supportdruk te verlagen

## Lege Toestanden

Belangrijke lijsten tonen een duidelijke lege toestand wanneer er nog geen data is.

Voorzien voor:

- venues
- medewerkers
- klanten
- onkosten
- werkbonnen
- verlof
- stock
- mijn taken / persoonlijke planning
- komende taken op medewerkerdashboard
- prikklokgeschiedenis
- tijdregistraties

Elke lege toestand bevat een korte uitleg, een kleine geanimeerde smiley en waar zinvol een directe actieknop.

## Navigatiestructuur

De sidebar gebruikt gegroepeerde, inklapbare secties zodat de app schaalbaar blijft wanneer er meer modules bijkomen.

Structuur:

- Super Admin: Start, Platform, Klantactivatie en Analyse
- Tenant Admin / manager: Start, Klantbeheer, Operaties, Analyse en Beheer
- Medewerker: Vandaag en Mijn werk
- Ingeklapte sidebar blijft icon-only voor snelle navigatie

## Wat nog demo/simulatie is

- Login is demo-login, geen echte auth.
- Stripe is simulatie.
- Robaws is lokale simulatie.
- Sociale secretariaten zijn simulatie.
- Bestanduploads worden niet naar cloud storage gestuurd.
- Rechten worden nog niet server-side afgedwongen.
- Auditlog is nog niet append-only.

## Wat klaar is voor verkoopdemo

- Rolgebaseerde ervaring
- Vrije rolcreatie
- Multi-tenant dashboard
- Operationele modules
- Billing-flow
- Integratie-flow
- Auditlog-concept
- Planlimieten
- Go-live checklist
