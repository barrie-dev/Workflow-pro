# WorkFlow Pro Technical Architecture

Versie: 0.1 local SaaS prototype  
Datum: 2026-04-27

## Architectuuroverzicht

De huidige WorkFlow Pro build is een lokale SaaS-demo met:

- Browser frontend op React
- Lokale Node HTTP-server
- JSON-bestand als persistente lokale opslag
- Browser localStorage fallback
- Simulatie-endpoints voor Robaws
- Platform-owner configuratie voor pricing, Stripe-status, feature flags en supporttoegang

```text
Browser
  index.html
  react-all.js
  app.js
      |
      | HTTP
      v
Node server.js
  static files
  /api/health
  /api/state
  /api/bootstrap
  /api/integrations/robaws/*
      |
      v
data/workflow-pro-db.json
```

## Runtime

Frontend:

- React 19 runtime via `react-all.js`
- Geen build step
- Geen bundler
- Geen externe CDN-afhankelijkheid

Backend:

- Node.js native `http`
- Native `fs` en `path`
- Geen Express of package dependencies

Dit maakt de demo eenvoudig te starten, maar is niet de gewenste productiearchitectuur.

## Frontend architectuur

`app.js` is opgebouwd als een flat bundle met function components.

Belangrijke lagen:

```text
Design tokens
  Kleuren, schaduw, statuskleuren

Permission layer
  ALL_PERMS, ROLE_DEFAULTS, PLAN_LIMITS, hasPerm()

Scope layer
  scopeV(), scopeU(), scopeC(), scopeE(), scopeW(), scopeL(), scopeS()

Seed data
  Users, tenants, venues, shifts, expenses, workorders, platformConfig, etc.

UI atoms
  Button, Card, Modal, Input, Select, Chip, Avatar, KPI

Pages
  Feature modules

App shell
  Auth/demo login, nav, routing, persistence
```

## Multi-tenancy

Demo-tenancy gebeurt via `tenantId` op entiteiten:

- users
- venues
- tenants
- custom roles
- shifts/workorders/expenses via user/venue relatie

Scope helpers beperken zichtbare data:

- `scopeV(venues, user)`
- `scopeU(users, user)`
- `scopeE(expenses, user, users)`
- `scopeW(workorders, user, users)`
- `scopeL(leaves, user, users)`
- `scopeS(shifts, user, venues)`

Productie-aanbeveling:

- PostgreSQL Row Level Security op elke tenant-tabel
- JWT bevat `user_id`, `tenant_id`, `role_id`, `permissions`
- Backend zet `app.current_tenant_id`
- Super admin gebruikt aparte service scope

## Rollen en rechten

## Platform Owner Console

De super admin heeft een apart `PlatformOwnerPage` scherm. Dit gebruikt `data.platformConfig` en laat de SaaS-eigenaar instellingen aanpassen zonder codewijziging:

- plannen en prijs per gebruiker
- trialdagen per plan
- BTW-percentage, jaarkorting, factuurprefix en dunningdagen
- add-on modules en moduleprijzen
- Stripe mode en configuratiestatus
- feature flags
- supportbeleid en toegestane support-login per tenant

In de huidige lokale demo wordt dit samen met de andere state bewaard in `data/workflow-pro-db.json` en `localStorage`. In productie mogen Stripe secrets niet in frontend-state terechtkomen. Bewaar secrets server-side, versleuteld, met auditlog en rotatiebeleid.

## Support Impersonation

Support-login is gemodelleerd via `tenant.supportAccess`.

Een tenant-admin kan in `SettingsPage` supporttoegang tijdelijk inschakelen. De super admin kan pas via `PlatformOwnerPage` inloggen als klant wanneer:

- `supportAccess.enabled` waar is
- `supportAccess.expiresAt` niet verlopen is

De supportsessie krijgt velden zoals `supportSession`, `supportTenantName` en `supportStartedAt`. Productie moet dit server-side afdwingen met:

- expliciete klanttoestemming
- korte sessieduur
- volledige audittrail
- read-only mode waar mogelijk
- duidelijke klantmelding dat support meekijkt

### Basisrollen

```text
super_admin
tenant_admin
venue_manager
employee
```

### Vrije rollen

Vrije rollen zitten in:

```text
customRoles[]
```

Structuur:

```json
{
  "id": "cr_finance",
  "tenantId": "t1",
  "name": "Finance",
  "desc": "Onkosten, rapportages, billing en integraties",
  "permissions": ["expenses", "reports", "billing", "integrations", "audit", "messages"]
}
```

### Module-permissies

```text
planning
clockings
expenses
workorders
stock
vehicles
leaves
messages
reports
integrations
billing
employees
venues
audit
```

Frontend navigatie wordt gefilterd via `hasPerm(user, perm)`.

Productie-aanbeveling:

- Maak `roles`, `role_permissions`, `users.role_id`.
- Sta custom roles per tenant toe.
- Gebruik backend middleware voor permission checks.
- Log elke wijziging in roles/permissions naar append-only auditlog.

## Data model in demo

Hoofdcollecties:

```text
users
tenants
venues
shifts
clocks
expenses
workorders
leaves
messages
vehicles
stock
customTypes
expLimits
customRoles
auditLogs
```

Belangrijke relaties:

```text
tenant -> users
tenant -> venues
user -> venueIds
shift -> userId + venueId
clock -> userId + venueId
expense -> userId + venueId
workorder -> userId + venueId
vehicle -> venueId + assignedTo
stock -> venueId
customRole -> tenantId
```

## Backend API

### Health

```text
GET /api/health
```

Response:

```json
{
  "ok": true,
  "app": "WorkFlow Pro",
  "mode": "local-saas",
  "time": "..."
}
```

### State

```text
GET /api/state
PUT /api/state
POST /api/bootstrap
```

`PUT /api/state` verwacht:

```json
{
  "data": {}
}
```

### Robaws simulatie

```text
POST /api/integrations/robaws/test
POST /api/integrations/robaws/sync
```

Deze endpoints zijn bedoeld als contractvoorbeeld voor de echte integratie.

## Auditlog

Auditgegevens zitten in:

```text
auditLogs[]
```

Structuur:

```json
{
  "id": "al1",
  "at": "2026-04-27",
  "time": "09:14",
  "actor": "Admin Claes",
  "action": "Rol aangepast",
  "area": "Rechten",
  "detail": "Werfleider Kim kreeg toegang tot werkbonnen en stock",
  "severity": "info"
}
```

Automatische auditregels worden toegevoegd in `upd()` voor kritieke collecties:

- users
- tenants
- venues
- customRoles
- expLimits
- expenses
- workorders
- integrations

Productie-aanbeveling:

- append-only tabel
- immutable records
- retention per plan
- exportfunctie voor GDPR/compliance

## Billing architectuur

Demo:

- `PLANS`
- `ADD_MODS`
- Stripe checkout simulatie
- card form in UI
- tenant plan/status in super admin
- planlimieten via `PLAN_LIMITS`

Productie:

- Stripe products/prices
- Stripe customer per tenant
- subscription status in database
- webhook endpoint
- customer portal
- failed payment/dunning state
- module entitlement enforcement

## Integratie-architectuur

Huidige integraties:

- Acerta
- Liantis
- SD Worx
- Securex
- Partena Professional
- Robaws

Robaws datavelden:

- Klanten
- Projecten
- Werkbonnen
- Materialen
- Uren
- Facturatie

Productie-aanpak:

```text
IntegrationConnection
  tenant_id
  provider
  status
  auth_type
  encrypted_credentials
  selected_fields
  last_sync_at

IntegrationSyncLog
  connection_id
  direction
  status
  records_in
  records_out
  errors
```

## Doelarchitectuur productie

Aanbevolen stack:

```text
Frontend
  React + TypeScript + Vite

Backend
  Node.js + Express/Fastify/NestJS

Database
  PostgreSQL + Row Level Security

Auth
  Supabase Auth/Auth0/Clerk/custom JWT

Billing
  Stripe

Storage
  S3-compatible EU object storage

Email
  Resend/Postmark

Hosting
  EU region: Vercel + Railway/Supabase Frankfurt
```

## Risico's voor marktgang

- Rechten zijn nog frontend-side.
- Geen echte authenticatie.
- Geen echte database migrations.
- Geen echte Stripe webhook.
- Geen echte file storage.
- Integratiecredentials worden nog niet versleuteld bewaard.
- Geen geautomatiseerde tests.

## Aanbevolen volgende technische mijlpalen

1. Split `app.js` naar TypeScript modules.
2. Voeg database schema en migraties toe.
3. Implementeer auth/JWT.
4. Verplaats permission checks naar backend.
5. Maak Stripe testmode werkend.
6. Maak Robaws staging koppeling werkend.
7. Voeg auditlog append-only toe.
8. Voeg E2E tests toe voor onboarding, rechten, billing en werkbonnen.
