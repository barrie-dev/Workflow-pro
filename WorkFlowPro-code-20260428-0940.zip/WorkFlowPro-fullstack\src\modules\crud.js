const { assertCan, assertTenant } = require("../lib/auth");
const { moduleByKey } = require("./registry");

function actorTenant(user, explicitTenantId) {
  return user.role === "super_admin" ? explicitTenantId : user.tenantId;
}

function listModule(store, user, key, tenantId) {
  const mod = moduleByKey(key);
  if (!mod) {
    const error = new Error("Unknown module");
    error.status = 404;
    throw error;
  }
  assertCan(user, mod.permission);
  if (!mod.tenantScoped) return store.list(mod.collection);
  const scopedTenant = actorTenant(user, tenantId);
  assertTenant(user, scopedTenant);
  return store.list(mod.collection, scopedTenant);
}

function createModuleRow(store, user, key, tenantId, payload) {
  const mod = moduleByKey(key);
  if (!mod) {
    const error = new Error("Unknown module");
    error.status = 404;
    throw error;
  }
  assertCan(user, mod.permission);
  const scopedTenant = mod.tenantScoped ? actorTenant(user, tenantId || payload.tenantId) : payload.tenantId || null;
  if (mod.tenantScoped) assertTenant(user, scopedTenant);
  const row = {
    id: payload.id || `${mod.collection}_${Date.now()}_${Math.random().toString(16).slice(2)}`,
    ...payload,
    ...(mod.tenantScoped ? { tenantId: scopedTenant } : {})
  };
  store.insert(mod.collection, row);
  store.audit({ actor: user.email, tenantId: scopedTenant, action: "create", area: mod.key, detail: row.id });
  return row;
}

function updateModuleRow(store, user, key, id, payload) {
  const mod = moduleByKey(key);
  if (!mod) {
    const error = new Error("Unknown module");
    error.status = 404;
    throw error;
  }
  assertCan(user, mod.permission);
  const existing = store.get(mod.collection, id);
  if (!existing) {
    const error = new Error("Not found");
    error.status = 404;
    throw error;
  }
  if (mod.tenantScoped) assertTenant(user, existing.tenantId);
  const row = store.update(mod.collection, id, payload);
  store.audit({ actor: user.email, tenantId: existing.tenantId, action: "update", area: mod.key, detail: id });
  return row;
}

module.exports = { listModule, createModuleRow, updateModuleRow };
