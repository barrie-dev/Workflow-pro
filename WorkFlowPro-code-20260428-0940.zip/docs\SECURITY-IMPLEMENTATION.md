# WorkFlow Pro Security Implementation Plan

Datum: 2026-04-27

## Doel

Deze securitylaag moet van de lokale demo een B2B SaaS maken die geschikt is voor Belgische KMO's en later grotere organisaties.

## P0 Voor Productie

### 1. Echte auth en MFA

Aanpak:

- Gebruik Supabase Auth, Auth0 of Clerk.
- MFA verplicht voor super admins en tenant admins.
- Wachtwoordreset en e-mailverificatie verplicht.
- JWT bevat `user_id`, `tenant_id`, `role_id`, `permissions_version`.
- Sessies hebben idle timeout en absolute expiry.

Acceptatiecriteria:

- Admin kan niet inloggen zonder MFA.
- Wachtwoordreset werkt via e-mail.
- Uitloggen invalidateert actieve sessie.
- Role change forceert nieuwe sessie.

### 2. Server-side tenant isolation

Aanpak:

- Alle entiteiten krijgen `tenant_id`.
- Alle API-calls filteren server-side op tenant.
- Productievoorkeur: PostgreSQL Row Level Security.
- Super admin gebruikt expliciete elevated service scope.

Acceptatiecriteria:

- Tenant A kan geen data van Tenant B lezen, ook niet via API.
- Tests proberen cross-tenant reads/writes.
- RLS policies dekken alle tenant-tabellen.

### 3. Encrypted credentials

Aanpak:

- Geen secrets in frontend of localStorage.
- Stripe, Robaws en integratiekeys server-side bewaren.
- Encryptie via KMS/Vault/provider secret manager.
- Key rotation en auditlog verplicht.

Acceptatiecriteria:

- Frontend ziet alleen `configured: true/false`.
- Secrets zijn niet exporteerbaar via API.
- Rotatiedatum en eigenaar worden gelogd.

### 4. Server-side rechten

Aanpak:

- Frontend permissies blijven UI-hints.
- Backend middleware controleert action-level permissions.
- Rechtenmodel splitsen in `view/create/update/delete/approve/export`.
- Scope: own/team/venue/tenant/all.

Acceptatiecriteria:

- API weigert acties zonder permissie.
- Role preview toont dezelfde regels als backend afdwingt.
- Rechtenwijziging logt oude en nieuwe waarde.

## P1 Compliance

### 5. DPA

Aanpak:

- DPA documentversie per tenant opslaan.
- Acceptatie: actor, datum, IP, documentversie.
- Zonder DPA geen productie-integraties activeren.

Acceptatiecriteria:

- Super admin ziet DPA-status per tenant.
- DPA exporteerbaar voor audit.

### 6. GDPR export/delete

Aanpak:

- Data subject request workflow.
- Export per medewerker in machine-readable formaat.
- Delete/anonymize met retentiechecks.
- Audittrail voor aanvraag, goedkeuring en uitvoering.

Acceptatiecriteria:

- GDPR export bevat relevante persoonsgegevens.
- Delete flow blokkeert data die wettelijk bewaard moet worden.
- Elke stap wordt geaudit.

## Support Impersonation

Aanpak:

- Klanttoestemming verplicht, tenzij klant auto-renew aanzet.
- Super admin moet reden invullen.
- Sessieduur beperkt.
- Session log bevat actor, klant, reden, IP, device, start/einde.
- Waar mogelijk read-only supportmodus.

Acceptatiecriteria:

- Zonder toestemming geen impersonation.
- Klant kan toestemming intrekken.
- Iedere support sessie verschijnt in security events.

## Productiestack Aanbeveling

Minimale stack:

- Frontend: huidige React app migreren naar Vite/Next.js.
- Auth: Supabase Auth of Auth0.
- Database: PostgreSQL met RLS.
- API: server-side routes met tenant middleware.
- Secrets: provider secret manager of KMS.
- Logging: audit/security event table.
- Hosting: EU-regio.

