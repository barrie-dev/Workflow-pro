function createSetupIntent(tenant) {
  return {
    provider: "stripe",
    mode: "test",
    tenantId: tenant.id,
    clientSecret: `seti_mock_${tenant.id}_${Date.now()}_secret_mock`,
    status: "requires_payment_method"
  };
}

function attachPaymentMethod(store, tenant, paymentMethodRef, actor) {
  const next = store.updateTenant(tenant.id, {
    paymentMethod: "Card token opgeslagen",
    billingStatus: "paid",
    billingOps: {
      ...(tenant.billingOps || {}),
      paymentMethodTokenized: true,
      paymentMethodRef,
      autoCharge: true
    }
  });
  store.audit({ actor: actor.email, tenantId: tenant.id, action: "payment_method_attached", area: "billing" });
  return next;
}

function createInvoice(store, tenant, payload, actor) {
  const billingOps = tenant.billingOps || {};
  const gross = Number(payload.amount || tenant.mrr * 12 || 0);
  const discountPct = Number(payload.discountPct || billingOps.discountPct || 0);
  const net = +(gross * (1 - discountPct / 100)).toFixed(2);
  const invoice = {
    id: `INV-${new Date().getFullYear()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
    at: new Date().toISOString().slice(0, 10),
    dueDate: payload.dueDate || new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10),
    line: payload.line || "WorkFlow Pro licentie",
    gross,
    discountPct,
    net,
    status: "draft",
    peppolStatus: tenant.invoiceProfile?.peppolId ? "ready" : "missing_peppol",
    enterpriseContract: tenant.plan === "enterprise"
  };
  const next = store.updateTenant(tenant.id, {
    billingOps: {
      ...billingOps,
      invoiceHistory: [...(billingOps.invoiceHistory || []), invoice]
    }
  });
  store.audit({ actor: actor.email, tenantId: tenant.id, action: "invoice_created", area: "billing", detail: invoice.id });
  return { tenant: next, invoice };
}

function sendPeppol(store, tenant, invoiceId, actor) {
  const billingOps = tenant.billingOps || {};
  const invoices = (billingOps.invoiceHistory || []).map(inv => (
    inv.id === invoiceId ? { ...inv, status: "sent", peppolStatus: "sent", sentAt: new Date().toISOString() } : inv
  ));
  const next = store.updateTenant(tenant.id, { billingOps: { ...billingOps, invoiceHistory: invoices } });
  store.audit({ actor: actor.email, tenantId: tenant.id, action: "peppol_sent", area: "billing", detail: invoiceId });
  return next;
}

module.exports = { createSetupIntent, attachPaymentMethod, createInvoice, sendPeppol };
