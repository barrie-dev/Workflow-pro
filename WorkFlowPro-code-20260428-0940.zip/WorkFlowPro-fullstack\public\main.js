let token = "";
const tenantId = "t_demo";

async function api(path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });
  return res.json();
}

function show(id, data) {
  document.getElementById(id).textContent = JSON.stringify(data, null, 2);
}

async function refresh() {
  show("health", await api("/api/health"));
  if (!token) return;
  show("modules", await api("/api/modules"));
  show("golden", await api(`/api/tenants/${tenantId}/golden-path`));
  show("today", await api(`/api/tenants/${tenantId}/mobile/today`));
}

document.getElementById("login").addEventListener("click", async () => {
  const result = await api("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ email: "admin@demobouw.be", password: "admin123" })
  });
  token = result.token || "";
  await refresh();
});

document.getElementById("demo").addEventListener("click", async () => {
  if (!token) return;
  show("golden", await api(`/api/tenants/${tenantId}/golden-path/demo`, { method: "POST", body: "{}" }));
  await refresh();
});

refresh();
