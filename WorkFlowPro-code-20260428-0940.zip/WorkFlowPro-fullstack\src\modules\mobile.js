function todayPayload(store, user) {
  const tenantId = user.tenantId;
  const today = new Date().toISOString().slice(0, 10);
  return {
    date: today,
    user: { id: user.id, name: user.name, role: user.role },
    shifts: store.list("shifts", tenantId).filter(s => s.userId === user.id && s.date === today),
    openWorkorders: store.list("workorders", tenantId).filter(w => w.userId === user.id && !["Voltooid", "Afgewerkt"].includes(w.status)),
    activeClock: store.list("clocks", tenantId).find(c => c.userId === user.id && c.date === today && !c.clockOut) || null,
    offlineHints: {
      pwaReady: false,
      syncQueue: 0,
      nextStep: "Service worker en IndexedDB queue toevoegen"
    }
  };
}

module.exports = { todayPayload };
