# API Contracts

## Auth

- `POST /api/auth/login`
- `GET /api/me`

Demo credentials:

- `admin@demobouw.be`
- `admin123`

## Module CRUD

- `GET /api/modules`
- `GET /api/modules/:moduleKey?tenantId=:tenantId`
- `POST /api/modules/:moduleKey`
- `PATCH /api/modules/:moduleKey/:id`

Module keys staan in `src/modules/registry.js`.

## Tenant actions

- `POST /api/kbo/lookup`
- `POST /api/tenants/:tenantId/kbo/apply`
- `GET /api/tenants/:tenantId/golden-path`
- `POST /api/tenants/:tenantId/golden-path/demo`
- `GET /api/tenants/:tenantId/mobile/today`

## Billing

- `POST /api/tenants/:tenantId/billing/setup-intent`
- `POST /api/tenants/:tenantId/billing/payment-method`
- `POST /api/tenants/:tenantId/billing/invoices`
- `POST /api/tenants/:tenantId/billing/peppol/:invoiceId`

## Audit

- `GET /api/audit`
